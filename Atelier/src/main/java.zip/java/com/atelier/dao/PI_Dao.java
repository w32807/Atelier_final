package com.atelier.dao;

import java.util.List;

import com.atelier.dto.PI_productImgDto;

public interface PI_Dao {

	public PI_productImgDto getPDImageList(int pd_code);
	
}
