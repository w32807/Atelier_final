package com.atelier.dto;

import lombok.Data;

@Data
public class AD_MaterialDto {
	private int RM_NUM;
	private String RM_TYPE;
	private String PRM_COMPANY;
	private String RM_COLOR;
	private int RM_PRICE;
}
