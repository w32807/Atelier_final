package com.atelier.dto;

import lombok.Data;

@Data
public class AG_Dto {
	private String ag_id;
	private String ag_at_name;
	private String ag_phone;
	private String ag_snsaddr;
	private String ag_cate1;
	private String ag_cate2;
	private String ag_cate3;
}
