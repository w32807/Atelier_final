package com.atelier.dto;

import lombok.Data;

@Data
public class AM_Dto {
	private	int		am_num;
	private String	am_id;
	private String	am_name;
	private String	am_phone;
	private String	am_addr;
	private String  am_sns;
	private String  am_cate1;
	private String  am_cate2;
	private String  am_cate3;
}
