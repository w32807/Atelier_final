package com.atelier.dto;

import lombok.Data;

@Data
public class AT_NT_Dto {
	private int at_nt_num;
	private String at_nt_title;
	private String at_nt_contents;
	private String at_nt_id;
	private int at_nt_count;
}
