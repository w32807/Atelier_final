package com.atelier.dto;

import lombok.Data;

@Data
public class AT_ProdDto {

	String pd_at_id;
	String pi_pd_code;
	String pi_oriname;
	String pd_name;
	String pd_price;
	String pd_sex;
}
