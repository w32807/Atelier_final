package com.atelier.dto;

import lombok.Data;

@Data
public class CM_Dto {

	private String cm_id;
	private String cm_pwd;
	private String cm_name;
	private String cm_nick;
	private String cm_phone;
	private String cm_addr;
	private String cm_addr2;
	private String cm_state;
	private String cm_pfphoto;
	
}
