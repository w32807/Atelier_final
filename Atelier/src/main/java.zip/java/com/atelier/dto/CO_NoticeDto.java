package com.atelier.dto;

import lombok.Data;

@Data
public class CO_NoticeDto {
	private int 	nt_num;
	private String 	nt_title;
	private String 	nt_contents;
	private String 	nt_id;
	private int 	nt_count;
}
