package com.atelier.dto;

import lombok.Data;

@Data
public class CT_Dto {
	private int ct_num;
	private String ct_name;
}
