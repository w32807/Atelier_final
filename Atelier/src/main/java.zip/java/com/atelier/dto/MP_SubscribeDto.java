package com.atelier.dto;

import lombok.Data;

@Data
public class MP_SubscribeDto {
	private int sc_num;
	private String sc_cm_id;
	private String sc_at_id;
	private String sc_at_name;
}