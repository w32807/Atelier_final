package com.atelier.dto;

import lombok.Data;

@Data
public class PI_productImgDto {

	
	private String pi_num;
	private int pi_pd_code;
	private String pi_sysname;
	private String pi_oriname;
	
	
}
