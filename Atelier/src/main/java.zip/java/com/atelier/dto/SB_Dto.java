package com.atelier.dto;

import lombok.Data;

@Data
public class SB_Dto {
	
	private int sc_num;			//구독코드
	private String sc_cm_id;	//회원아이디 이메일
	private String sc_at_id;	//공방아이디 이메일
	

}
